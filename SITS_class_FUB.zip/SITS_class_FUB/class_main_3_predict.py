import os
import glob
import time
from pytorch.predict import predict_init, load_preprocess_settings
from config_path import path_params
from force.force_class_utils import force_class


args_predict = {
    'project_name': "FIVEOFIVE",
    'model_path': '/ugh_mount/FORCE/new_struc/process/results/_SITSModels/new_BI_nogaps/transformer/model_e128.pth',
    # 'aois': glob.glob(f"/ugh_mount/predict1shp/predict1shp.shp"), # aois can be path or list. Path for Force Tile folder or list // process structure and shapefiles must be correct
    # 'aois': glob.glob(f"/ugh_mount/germany_prediction_aois/oneofive.shp"), # aois can be path or list. Path for Force Tile folder or list // process structure and shapefiles must be correct
    'aois': glob.glob(f"/ugh_mount/germany_prediction_aois/fiveofive_2023.shp"),
    # 'aois': None,
    'chunksize': 2000, 
    # 'reference_folder' : '/ugh_mount/ref_folder/sepfiles/test_for_FE_nogaps/csv/singles', #Set Path if you want to predict the Test CSV File
    # 'reference_folder' : 'ugh_mount/FORCE/new_struc/process/results/_SITSrefdata/Testdata_for_FE_nogaps/sepfiles/test' ,
    'reference_folder' : None,
    'probability' : True, # just gets recognized if classification
    'order' : ['BLU', 'GRN', 'RED', 'NIR', 'SW1', 'SW2', 'RE1', 'RE2', 'RE3', 'BNR'],
}
##########################################
### Additional Setting - Can Be Ignored###
##########################################
preprocess_params = load_preprocess_settings(os.path.dirname(args_predict["model_path"]))
preprocess_params["sample"] = False
preprocess_params["project_name"] = args_predict["project_name"]
preprocess_params["aois"] = args_predict["aois"]
preprocess_params["date_ranges"] = None
preprocess_params["years"] = None
args_predict["time_range"] = preprocess_params["time_range"]
# args_predict["test_gpkg"] = '/ugh_mount/test_data/Testdata_for_FE_nogaps_3035.gpkg'


# gpkg = args_predict["test_gpkg"]
if __name__ == '__main__':
    startzeit = time.time()

    # force_class(preprocess_params, **path_params)
    predict_init(args_predict, **path_params)

    endzeit = time.time()
    print(f"{(endzeit-startzeit)/60} minutes")

import os
import torch
import rasterio
import sys
import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier
from pathlib import Path
from tqdm import tqdm
import glob
import json
import datetime
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
from rasterio.merge import merge
from pytorch.utils.hw_monitor import HWMonitor, disk_info, squeeze_hw_info

def truncate_and_pad_sequences(sequences, maxlen):
    truncated_padded = []
    for seq in sequences:
        if seq.ndim == 1:
            if len(seq) > maxlen:
                truncated_padded.append(seq[:maxlen])
            else:
                padded_seq = np.pad(seq, (0, maxlen - len(seq)), 'constant')
                truncated_padded.append(padded_seq)
        else:
            if seq.shape[0] > maxlen:
                truncated_padded.append(seq[:maxlen])
            else:
                pad_width = [(0, maxlen - seq.shape[0])] + [(0, 0) for _ in range(seq.ndim - 1)]
                padded_seq = np.pad(seq, pad_width, 'constant')
                truncated_padded.append(padded_seq)
    return truncated_padded

def reshape_for_sklearn(sequences):
    n_samples = len(sequences)
    return np.reshape(sequences, (n_samples, -1))

def load_rf_model(model_path):
    print(f"Loading RandomForest model from {model_path}...")
    model = joblib.load(model_path)
    print("Model loaded successfully.")
    return model

def load_preprocess_settings(model_name):
    """
    Load the hyperparameters from a JSON file.
    """
    file_path = os.path.join(model_name, "preprocess_settings.json")
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"No hyperparameters file found at {file_path}")
    with open(file_path, 'r') as file:
        hyperparameters = json.load(file)
    return hyperparameters

def prepare_rf_data(data, maxlen):
    data = truncate_and_pad_sequences(data, maxlen)
    data = reshape_for_sklearn(data)
    return np.array(data)

def mosaic_rasters(input_pattern, output_filename):
    """
    Mosaic rasters matching the input pattern and save to output_filename.

    Parameters:
    - input_pattern: str, a wildcard pattern to match input raster files (e.g., "./tiles/*.tif").
    - output_filename: str, the name of the output mosaic raster file.
    """
    src_files_to_mosaic = [rasterio.open(fp) for fp in input_pattern]
    mosaic, out_transform = merge(src_files_to_mosaic)
    out_meta = src_files_to_mosaic[0].meta.copy()
    out_meta.update({
        "driver": "GTiff",
        "height": mosaic.shape[1],
        "width": mosaic.shape[2],
        "transform": out_transform,
    })
    if not os.path.exists(os.path.dirname(output_filename)):
        os.makedirs(os.path.dirname(output_filename))
    with rasterio.open(output_filename, 'w', **out_meta) as dest:
        dest.write(mosaic)
    for src in src_files_to_mosaic:
        src.close()

def read_rf_tif_files(folder_path, order):
    bands_data = []
    for band in order:
        file_pattern = os.path.join(folder_path, f"*{band}_*.tif")
        file_list = glob.glob(file_pattern)
        if len(file_list) == 0:
            raise FileNotFoundError(f"No file found for pattern {file_pattern}")
        file_path = file_list[0]
        with rasterio.open(file_path) as src:
            band_data = src.read(1)
            band_data[band_data == -9999] = 0
            bands_data.append(band_data)
    return np.stack(bands_data, axis=-1)

def rf_predict(model, tile_path, args_predict):
    order = args_predict["order"]
    maxlen = args_predict["seqlength"]
    data = read_rf_tif_files(tile_path, order)
    data = data.reshape(-1, data.shape[-1])
    data = prepare_rf_data(data, maxlen)
    predictions = model.predict(data)
    return predictions

def rf_reshape_and_save(predictions, tile_path, args_predict):
    predictions = predictions.reshape(3000, 3000)
    existing_tif_path = glob.glob(os.path.join(tile_path, "*.tif"))[0]
    if not existing_tif_path:
        raise FileNotFoundError("No TIFF files found in the folder to copy metadata.")
    with rasterio.open(existing_tif_path) as src:
        metadata = src.meta
    metadata.update(dtype=rasterio.uint8, nodata=255, count=1)
    output_path = os.path.join(tile_path, "predicted.tif")
    with rasterio.open(output_path, 'w', **metadata) as dst:
        dst.write(predictions.astype(rasterio.uint8), 1)

def load_hyperparametersplus(model_name):
    file_path = os.path.join(model_name, "hyperparameters.json")
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"No hyperparameters file found at {file_path}")
    with open(file_path, 'r') as file:
        hyperparameters = json.load(file)
    return hyperparameters

def predict_rf_raster(args_predict):
    hyp = load_hyperparametersplus(os.path.dirname(args_predict["model_path"]))
    args_predict.update(hyp)
    drive_name = ["sdb1"]
    Path(args_predict['store'] + '/' + args_predict['model'] + '/hw_monitor').mkdir(parents=True, exist_ok=True)
    hw_predict_logs_file = args_predict['store'] + '/' + args_predict['model'] + '/hw_monitor/hw_monitor_predict.csv'
    hwmon_p = HWMonitor(1, hw_predict_logs_file, drive_name)
    hwmon_p.start()
    hwmon_p.start_averaging()
    model_path = args_predict['model_path']
    tiles = args_predict['folder_path']
    glob_tiles = glob.glob(tiles)
    model = load_rf_model(model_path)
    for tile in glob_tiles:
        print("###" * 15)
        print(f"Started Prediction for Tile {os.path.basename(tile)}")
        prediction = rf_predict(model, tile, args_predict)
        rf_reshape_and_save(prediction, tile, args_predict)
    hwmon_p.stop_averaging()
    avgs = hwmon_p.get_averages()
    squeezed = squeeze_hw_info(avgs)
    mean_data = {key: round(value, 1) for key, value in squeezed.items() if "mean" in key}
    print(f"##################\nMean Values Hardware Monitoring (Prediction):\n{mean_data}\n##################")
    hwmon_p.stop()

def predict_rf_csv(args_predict):
    output_path = args_predict["reference_folder"]
    reference_folder = args_predict["reference_folder"]
    folder_path = reference_folder + "/sepfiles/test/csv"
    meta_path = reference_folder + "/meta.csv"
    hyp = load_hyperparametersplus(os.path.dirname(args_predict["model_path"]))
    args_predict.update(hyp)
    model_path = args_predict['model_path']
    order = args_predict["order"]
    model = load_rf_model(model_path)
    metadata_df = pd.read_csv(meta_path)
    predictions_df = pd.DataFrame(columns=['x', 'y', 'label', 'prediction'])
    for idx, row in tqdm(metadata_df.iterrows(), total=metadata_df.shape[0]):
        csv_file_path = os.path.join(folder_path, f"{row['global_idx']}.csv")
        if not os.path.exists(csv_file_path):
            continue
        pixel_df = pd.read_csv(csv_file_path)
        data = pixel_df[order].values
        data = prepare_rf_data([data], args_predict['seqlength'])
        prediction = model.predict(data)[0]
        new_row_df = pd.DataFrame([{
            'x': row['x'],
            'y': row['y'],
            'label': pixel_df['label'].iloc[0],
            'prediction': prediction
        }])
        predictions_df = pd.concat([predictions_df, new_row_df], ignore_index=True)
    predictions_df.to_csv(os.path.join(output_path, "predictions.csv"), index=False)
    gdf = gpd.GeoDataFrame(
        predictions_df,
        geometry=[Point(xy) for xy in zip(predictions_df.x, predictions_df.y)],
        crs="EPSG:3035"
    )
    gdf.to_file(os.path.join(output_path, "predictions.shp"))
    return predictions_df

def predict_rf_init(args_predict, proc_folder, temp_folder, **kwargs):
    if not args_predict['reference_folder']:
        if isinstance(args_predict['aois'], list):
            for basen in args_predict['aois']:
                basename = os.path.basename(basen)
                args_predict['folder_path'] = f"{temp_folder}/{args_predict['project_name']}/FORCE/{basename}/tiles_tss/X*"
                predict_rf_raster(args_predict)
                files = glob.glob(f"{temp_folder}/{args_predict['project_name']}/FORCE/{basename}/tiles_tss/X*/predicted.tif")
                output_filename = f"{proc_folder}/{args_predict['project_name']}/{os.path.basename(basen.replace('.shp', '.tif'))}"
                mosaic_rasters(files, output_filename)
        else:
            predict_rf_raster(args_predict)
    else:
        predict_rf_csv(args_predict)

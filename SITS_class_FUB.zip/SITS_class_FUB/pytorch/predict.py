import os
import torch
import rasterio
import sys
import numpy as np
import joblib
from sklearn.metrics import confusion_matrix
from pathlib import Path
import time
from pytorch.train import getModel
from pytorch.utils.hw_monitor import HWMonitor, disk_info, squeeze_hw_info
from tqdm import tqdm
import glob
import json
import datetime
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
from rasterio.merge import merge
from rasterio.mask import mask

def truncate_and_pad_sequences(sequences, maxlen):
    truncated_padded = []
    for seq in sequences:
        if seq.ndim == 1:
            if len(seq) > maxlen:
                truncated_padded.append(seq[:maxlen])
            else:
                padded_seq = np.pad(seq, (0, maxlen - len(seq)), 'constant')
                truncated_padded.append(padded_seq)
        else:
            if seq.shape[0] > maxlen:
                truncated_padded.append(seq[:maxlen])
            else:
                pad_width = [(0, maxlen - seq.shape[0])] + [(0, 0) for _ in range(seq.ndim - 1)]
                padded_seq = np.pad(seq, pad_width, 'constant')
                truncated_padded.append(padded_seq)
    return truncated_padded

def reshape_for_sklearn(sequences):
    n_samples = len(sequences)
    return np.reshape(sequences, (n_samples, -1))

def prepare_data(dataset, maxlen):
    X, _ = zip(*[(x.numpy(), y.numpy()) for x, y, _ in dataset])
    X = truncate_and_pad_sequences(X, maxlen)
    X = reshape_for_sklearn(X)
    return np.array(X)

def mosaic_rasters(input_pattern, output_filename):
    """
    Mosaic rasters matching the input pattern and save to output_filename.

    Parameters:
    - input_pattern: str, a wildcard pattern to match input raster files (e.g., "./tiles/*.tif").
    - output_filename: str, the name of the output mosaic raster file.
    """

    # Find all files matching the pattern
    src_files_to_mosaic = [rasterio.open(fp) for fp in input_pattern]

    # Mosaic the rasters
    mosaic, out_transform = merge(src_files_to_mosaic)
    #mosaic[mosaic == 0] = -9999
    # Get metadata from one of the input files
    out_meta = src_files_to_mosaic[0].meta.copy()

    # Update metadata with new dimensions, transform, and compression (optional)
    out_meta.update({
        "driver": "GTiff",
        "height": mosaic.shape[1],
        "width": mosaic.shape[2],
        "transform": out_transform,
        #"compress": "lzw"
    })
    if not os.path.exists(os.path.dirname(output_filename)):
        print(f"output folder doesnt exist ... creating {os.path.dirname(output_filename)}")
        os.makedirs(os.path.dirname(output_filename))
    # Write the mosaic raster to disk
    with rasterio.open(output_filename, "w", **out_meta) as dest:
        dest.write(mosaic)

    # Close the input files
    for src in src_files_to_mosaic:
        src.close()

def load_model(model_path,args):

    # Load a PyTorch model from the given path
    saved_state = torch.load(model_path)
    model_state_dict = saved_state["model_state"]
    args['nclasses'] = saved_state["nclasses"]
    args['seqlength'] = 366*int(args["time_range"][0])
    args['input_dims'] = saved_state["ndims"]
    #print(f"Sequence Length: {args['seqlength']}")
    print(f"Input Dims: {args['input_dims']}")
    print(f"Prediction Classes: {args['nclasses']}")
    model = getModel(args)

    model.load_state_dict(model_state_dict)

    model.eval()  # Set the model to evaluation mode
    return model

def read_tif_file(file_path):
    with rasterio.open(file_path) as src:
        # Read the specific band data from the TIFF file
        band_data = src.read()
        band_data[band_data == -9999] = 0
        return band_data

def read_tif_files(folder_path, order, year, month, day, gpkg_path = None):

    if gpkg_path != None:
        gdf = gpd.read_file(gpkg_path)
        geometries = gdf.geometry.values

    bands_data = []
    timesteps = []
    print(folder_path)
    for band in order:
        # print('x')
        # Find the file that matches the pattern
        file_pattern = os.path.join(folder_path, f"*{band}_*.tif")
        file_list = glob.glob(file_pattern)

        if len(file_list) == 0:
            raise FileNotFoundError(f"No file found for pattern {file_pattern}")
        else:
            print('.')

        # Assuming there's only one file per pattern
        file_path = file_list[0]
        if gpkg_path != None:
            with rasterio.open(file_path) as src:
                try:
                # Mask the raster with the GeoPackage geometries
                    out_image, out_transform = rasterio.mask.mask(src, geometries, crop=True)
                    out_image[out_image == -9999] = 0
                    bands_data.append(out_image)

                # Extract the timestamp description if needed
                    if band == order[0]:  # Extract only once
                        timestamp = src.descriptions  # Assuming you need the first description for DOY

                except ValueError:
                # Skip to the next raster if there is no overlap
                    print(f"No overlap found for raster {file_path}. Skipping.")
                    continue
    
        if gpkg_path == None:
            with rasterio.open(file_path) as src:
            # Read all bands from the TIFF file
                band_data = src.read()
                band_data[band_data == -9999] = 0
                band_data = band_data
                bands_data.append(band_data)

            with rasterio.open(file_path) as src:
                timestamp = src.descriptions  # Assuming you need the first description for DOY

        if bands_data:  # Ensure there is at least one valid band loaded
            # Extract DOY information from the timestamp
                doa_dates = [datetime.datetime.strptime(str(doa[:8]), '%Y%m%d') for doa in timestamp]

                latest_year = max(doa_dates, key=lambda x: x.year).year
                start_date = datetime.datetime(latest_year-year, month, day)
                doy = [(doa_date - start_date).days + 1 for doa_date in doa_dates]
        else:
            raise ValueError("No valid rasters found with overlap.")

    return bands_data, doy

def predict(model, tiles, args_predict):
    print(f"Preprocessing the Data for Prediction ...")
    print(time.gmtime())
    # Read TIFF files
    order = args_predict["order"]
    normalizing_factor = args_predict["norm_factor_features"]
    chunksize = args_predict["chunksize"]
    year = int(args_predict['time_range'][0])
    month = int(args_predict['time_range'][1].split('-')[0])
    day = int(args_predict['time_range'][1].split('-')[1])
    
    data, doy_single = read_tif_files(tiles, order, year, month, day)
    # Stack the bands and perform initial reshape in NumPy
    data = np.stack(data, axis=1)

    # Reshape data for PyTorch [sequence length, number of bands, height, width]
    seq_len, num_bands, height, width = data.shape
    XY = height * width
    data = data.reshape(seq_len, num_bands, XY)

    # Reorder dimensions for PyTorch [XY, number of bands, sequence length] using NumPy
    data = np.transpose(data, (2, 1, 0))
    # Move model to the appropriate device
    device = next(model.parameters()).device

    # data = np.load("/ugh_mount/npy/data_tif.npy")

    predictions = []
    print(f"Predicting with Chunksize {chunksize} from {data.shape[0]}")
    with torch.no_grad():
        for i in tqdm(range(0, data.shape[0], chunksize)):
            batch = data[i:i + chunksize] * normalizing_factor
            # np.save('/ugh_mount/compare/tifdata.npy', data)
            # np.save('/ugh_mount/compare/tifbatch.npy', batch)
            # batch = np.load('/ugh_mount/compare/csvbatch.npy')
            # doy_single = doy_single[:86] # uncomment for bugfixing with batch
            # batch = np.load('/ugh_mount/npy/118903069356_bands.npy')
            # doy = np.load('/ugh_mount/npy/118903069356_doy.npy')
            # 
            # doy_single2 = doy_single2.tolist()
            non_zero_mask = np.any(batch != 0, axis=(1, 2))
            doy = np.array(doy_single)
            doy = np.tile(doy, (batch.shape[0], 1))

            if not np.any(non_zero_mask):
                batch_predictions = torch.full((batch.shape[0], 1), -9999, dtype=torch.float32, device=device)
            else:
                batch_non_zero = batch[non_zero_mask]
                doy_non_zero = doy[non_zero_mask]
                batch_tensor = torch.tensor(batch_non_zero, dtype=torch.float32, device=device)
                doy_tensor = torch.tensor(doy_non_zero, dtype=torch.long, device=device)

                predictions_non_zero = model(batch_tensor, doy_tensor)[0]

                # Handle normalization response factor
                norm_factor_response = args_predict.get("norm_factor_response")
                if norm_factor_response == "log":
                    predictions_non_zero = torch.pow(10, predictions_non_zero) - 1
                elif norm_factor_response is not None and norm_factor_response != 0:
                    predictions_non_zero = predictions_non_zero / norm_factor_response

                if args_predict["response"] == "classification" and not args_predict["probability"]:
                    predictions_non_zero = torch.argmax(predictions_non_zero, dim=1).unsqueeze(1)  # Ensure 2D
                    predictions_non_zero = predictions_non_zero.to(torch.float32)

                batch_predictions = torch.full((batch.shape[0], *predictions_non_zero.shape[1:]), -9999, dtype=torch.float32, device=device)
                batch_predictions[non_zero_mask] = predictions_non_zero

            predictions.append(batch_predictions.cpu())  # Move predictions back to CPU if needed

    return torch.cat(predictions, dim=0)

def reshape_and_save(predictions, tiles, args_predict):
    # Reshape the predictions to 3000x3000
    num_bands = predictions.shape[1]
    if num_bands >1:
        reshaped_predictions = predictions.reshape(3000, 3000, num_bands).cpu().numpy()
        reshaped_predictions = reshaped_predictions.transpose((2, 0, 1))
    else:
        reshaped_predictions = predictions.reshape(3000, 3000).cpu().numpy()

    # Find one of the existing TIFF files to copy the metadata
    existing_tif_path = glob.glob(os.path.join(tiles, "*.tif"))[0]
    if not existing_tif_path:
        raise FileNotFoundError("No TIFF files found in the folder to copy metadata.")


    # Read the existing TIFF file to get metadata
    with rasterio.open(existing_tif_path) as src:
        metadata = src.meta

    if args_predict["response"] == "classification" and not args_predict["probability"]:
        reshaped_predictions = reshaped_predictions.astype('uint8')
        metadata.update(dtype=rasterio.uint8, nodata=255, count=1)
    elif args_predict["response"] == "classification" and args_predict["probability"]:
        metadata.update(dtype=rasterio.float32, count=num_bands)
    else:
        metadata.update(dtype=rasterio.float32, count=1)

    # Write the predictions to a new TIFF file
    output_path = os.path.join(tiles, "predicted.tif")
    with rasterio.open(output_path, 'w', **metadata) as dst:
        if num_bands == 1:
            # Write a single band
            dst.write(reshaped_predictions, 1)
        else:
            # Iterate over each band and write
            for band in range(num_bands):
                dst.write(reshaped_predictions[band], band + 1)

def load_hyperparametersplus(model_name):
    """
    Load the hyperparameters from a JSON file.
    """
    file_path = os.path.join(model_name, "hyperparameters.json")
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"No hyperparameters file found at {file_path}")
    with open(file_path, 'r') as file:
        hyperparameters = json.load(file)
    return hyperparameters

def load_preprocess_settings(model_name):
    """
    Load the hyperparameters from a JSON file.
    """
    file_path = os.path.join(model_name, "preprocess_settings.json")
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"No hyperparameters file found at {file_path}")
    with open(file_path, 'r') as file:
        hyperparameters = json.load(file)
    return hyperparameters

def predict_raster(args_predict, refdir = None):

    hyp = load_hyperparametersplus(os.path.dirname(args_predict["model_path"]))
    args_predict.update(hyp)

    # create hw_monitor output dir if it doesn't exist
    drive_name = ["sdb1"]
    Path(args_predict['store'] + '/' + args_predict['model'] + '/hw_monitor').mkdir(parents=True, exist_ok=True)

    hw_predict_logs_file = args_predict['store'] + '/' + args_predict['model'] + '/hw_monitor/hw_monitor_predict.csv'
    # Instantiate monitor with a 1-second delay between updates
    hwmon_p = HWMonitor(1,hw_predict_logs_file,drive_name)
    hwmon_p.start()
    hwmon_p.start_averaging()

    model_path = args_predict['model_path']
    model = load_model(model_path,args_predict)

    if refdir == None:

        tiles = args_predict['folder_path']
        glob_tiles = glob.glob(tiles)
    
        for tile in glob_tiles:
            print("###" * 15)
            print(f"Started Prediction for Tile {os.path.basename(tile)}")
            prediction = predict(model,tile,args_predict)
            reshape_and_save(prediction,tile,args_predict)

        hwmon_p.stop_averaging()
        avgs = hwmon_p.get_averages()
        squeezed = squeeze_hw_info(avgs)
        mean_data = {key: round(value, 1) for key, value in squeezed.items() if "mean" in key}
        print(f"##################\nMean Values Hardware Monitoring (Prediction):\n{mean_data}\n##################")
        hwmon_p.stop()

    else: # if refdir is set, this means a dir with csv files is provided.
       print(datetime.datetime.now())
       ids, prediction =  predict_csv3(model, refdir, args_predict)
       print('done')
       print(datetime.datetime.now())
       import csv
       predictions_as_int = [int(tensor.item()) for tensor in prediction]  # Or use float() if needed
       with open('/ugh_mount/30m_FE_nogaps_ref2.csv', 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["id", "prediction"])
            for id_value, prediction_value in zip(ids, predictions_as_int):
                writer.writerow([id_value, prediction_value])
            # for value in predictions_as_int:
            #     writer.writerow([value])  

def predict_csv2(model, refdir, args_predict):
    print(f"Preprocessing the Data for Prediction ...")
    print(time.gmtime())
    # Get files
    os.chdir(refdir)
    csv = glob.glob('*.{}'.format('csv'))
    # Prepare a DataFrame to hold all predictions
    df = pd.DataFrame(columns=['x', 'y', 'label', 'prediction'])
    order = args_predict["order"]
    normalizing_factor = args_predict["norm_factor_features"]
    chunksize = args_predict["chunksize"]
    year = int(args_predict['time_range'][0])
    month = int(args_predict['time_range'][1].split('-')[0])
    day = int(args_predict['time_range'][1].split('-')[1])

    data, doy_single = read_csv_singles(csv, order, year, month, day, normalizing_factor)
    chunksize = 2000

    data = np.stack(data, axis=1)

    # Reorder dimensions for PyTorch [XY, number of bands, sequence length] using NumPy
    data = np.transpose(data, (1, 0))
    data = np.expand_dims(data, axis=0)
    data = np.concatenate([data] * 2000, axis=0) #  cloning to evade dim issues
            
    # Move model to the appropriate device
    device = next(model.parameters()).device

    predictions = []
    print(f"Predicting with Chunksize {chunksize} from {data.shape[0]}")
    with torch.no_grad():
        for i in tqdm(range(0, data.shape[0], chunksize)):
            batch = data * normalizing_factor
            # np.save('/ugh_mount/compare/csvdata.npy', data)
            # np.save('/ugh_mount/compare/csvbatch.npy', batch)
            batch = np.load('/ugh_mount/compare/csvbatch.npy')

            # doy_single = np.random.choice(doy_single, size=122, replace = True)
            # doy_single = np.concatenate(doy_single, doy_single2)
            # predict_csv2 doesn't work with tif data either bu t predict() works fine with csv data?? wtf? code difference?
            non_zero_mask = np.any(batch != 0, axis=(1, 2))
            doy = np.array(doy_single)
            doy = np.tile(doy, (batch.shape[0], 1))

            if not np.any(non_zero_mask):
                batch_predictions = torch.full((batch.shape[0], 1), -9999, dtype=torch.float32, device=device)
            else:
                batch_non_zero = batch[non_zero_mask]
                doy_non_zero = doy[non_zero_mask]
                batch_tensor = torch.tensor(batch_non_zero, dtype=torch.float32, device=device)
                doy_tensor = torch.tensor(doy_non_zero, dtype=torch.long, device=device)

                predictions_non_zero = model(batch_tensor, doy_tensor)[0]

                # Handle normalization response factor
                norm_factor_response = args_predict.get("norm_factor_response")
                if norm_factor_response == "log":
                    predictions_non_zero = torch.pow(10, predictions_non_zero) - 1
                elif norm_factor_response is not None and norm_factor_response != 0:
                    predictions_non_zero = predictions_non_zero / norm_factor_response

                if args_predict["response"] == "classification" and not args_predict["probability"]:
                    predictions_non_zero = torch.argmax(predictions_non_zero, dim=1).unsqueeze(1)  # Ensure 2D
                    predictions_non_zero = predictions_non_zero.to(torch.float32)

                batch_predictions = torch.full((batch.shape[0], *predictions_non_zero.shape[1:]), -9999, dtype=torch.float32, device=device)
                batch_predictions[non_zero_mask] = predictions_non_zero

            predictions.append(batch_predictions.cpu())  # Move predictions back to CPU if needed

    return torch.cat(predictions, dim=0)

# Function to extract date and convert to datetime
def extract_date(date_str):
    if date_str.startswith('X'):
        date_part = date_str[1:].split('_')[0]  # Remove 'X' and get date part
        return pd.to_datetime(date_part, format='%Y%m%d')
    return pd.NaT

def read_csv_singles(csv, order, year, month, day, normalizing_factor):
    bands_data = []
    for file in csv:
        pixel_df = pd.read_csv(file)
        pixel_df = pixel_df.drop(0).reset_index(drop=True) # drop first row contaning BS
        pixel_df = pixel_df.fillna(0) # replace NA with 0s

        # calculate DOY
        pixel_df['date'] = pixel_df['date'].apply(extract_date)
        pixel_df = pixel_df.dropna(subset=['date'])
        pixel_df['doy'] = pixel_df['date'].dt.dayofyear
        # Extract the year from the date
        pixel_df['year'] = pixel_df['date'].dt.year
        cumulative_doy = []
        total_days = 0
        previous_year = None
        for i, row in pixel_df.iterrows():
            current_year = row['year']
            
            # Check if we moved to a new year
            if previous_year is None or current_year != previous_year:
                if previous_year is not None:
                    total_days += 365  # Add 365 days for each completed year
            
            # Add the current DOY to the cumulative total
            cumulative_doy.append(total_days + row['doy'])
            
            previous_year = current_year  # Update the previous year

        pixel_df['cumulative_doy'] = cumulative_doy
        data = pixel_df[order].values
        doy = pixel_df['cumulative_doy'].values
        bands_data = [np.array([]) for _ in range(data.shape[1])]
        
        for i in range(data.shape[1]):
            column_data = data[:, i]  # Get the i-th column
            bands_data[i] = np.append(bands_data[i], column_data)

        bands_data = np.stack(bands_data, axis=1)

        # Reorder dimensions for PyTorch [XY, number of bands, sequence length] using NumPy
        bands_data = np.transpose(bands_data, (1, 0))
        bands_data = np.expand_dims(bands_data, axis=0)
        bands_data = np.concatenate([bands_data] * 2000, axis=0) #  cloning to evade dim issues
        
        bands_data = bands_data * normalizing_factor

        basename = os.path.splitext(file)[0]
        bandsname = '/ugh_mount/npy/' + basename + '_bands' + '.npy'
        doyname = '/ugh_mount/npy/' + basename + '_doy' + '.npy'

        np.save(bandsname, bands_data)
        np.save(doyname, doy)

    return bands_data, doy

def predict_csv(args_predict):

    output_path = args_predict["reference_folder"]
    reference_folder = args_predict["reference_folder"]
    folder_path = reference_folder
    meta_path = reference_folder+"/meta.csv"

    hyp = load_hyperparametersplus(os.path.dirname(args_predict["model_path"]))
    args_predict.update(hyp)
    model_path = args_predict['model_path']
    order = args_predict["order"]
    model = load_model(model_path, args_predict)

    # Load metadata
    # metadata_df = pd.read_csv(meta_path)
    # load csv file paths:
    metadata_df = [os.path.join(folder_path, file) for file in os.listdir(folder_path)]
    # Prepare a DataFrame to hold all predictions
    df = pd.DataFrame(columns=['x', 'y', 'label', 'prediction'])

    # Function to extract date and convert to datetime
    def extract_date(date_str):
        if date_str.startswith('X'):
            date_part = date_str[1:].split('_')[0]  # Remove 'X' and get date part
            return pd.to_datetime(date_part, format='%Y%m%d')
        return pd.NaT

    # Iterate over CSV files
    for idx in tqdm(metadata_df):
        
        # Read spectral data
        pixel_df = pd.read_csv(idx)
        pixel_df = pixel_df.drop(0).reset_index(drop=True)
        pixel_df = pixel_df.fillna(0)

        pixel_df['date'] = pixel_df['date'].apply(extract_date)
        pixel_df = pixel_df.dropna(subset=['date'])
        pixel_df['doy'] = pixel_df['date'].dt.dayofyear
        # Extract the year from the date
        pixel_df['year'] = pixel_df['date'].dt.year
        cumulative_doy = []
        total_days = 0
        previous_year = None
        for i, row in pixel_df.iterrows():
            current_year = row['year']
            
            # Check if we moved to a new year
            if previous_year is None or current_year != previous_year:
                if previous_year is not None:
                    total_days += 365  # Add 365 days for each completed year
            
            # Add the current DOY to the cumulative total
            cumulative_doy.append(total_days + row['doy'])
            
            previous_year = current_year  # Update the previous year

        pixel_df['cumulative_doy'] = cumulative_doy

        # Extract relevant columns and normalize if necessary
        data = pixel_df[order].values
        doy = pixel_df['cumulative_doy'].values

        # Preprocess data for the model
        data = data * args_predict['norm_factor_features']  # Normalize data
        data = torch.tensor(data, dtype=torch.float32).unsqueeze(0)  # Add batch dimension
        data = data.permute(0, 2, 1)  # This swaps the second and third dimensions

        doy = torch.tensor(doy, dtype=torch.long)
        device = next(model.parameters()).device
        data = data.to(device)  # Move data tensor to the correct device
        doy = doy.to(device)  # Ensure 'doy' tensor is also on the correct device
        # Predict
        with torch.no_grad():
            prediction = model(data, doy)[0]
            # prediction = predict(model,tile,args_predict)
            # prediction = model(tile, args, predict)[0]
            if args_predict["response"] == "classification":
                prediction = torch.argmax(prediction, dim=1)
            prediction = prediction.squeeze().item()  # Assuming single prediction
            if args_predict["norm_factor_response"] != None:
                prediction = prediction / (args_predict["norm_factor_response"])
            elif args_predict["norm_factor_response"] == "log":
                prediction = 10 ** prediction - 1  # Reverse log10(x + 1) using Python's scalar operations


            # Create a DataFrame for the new row you want to add
            new_row_df = pd.DataFrame([{
                'x': row['x'],
                'y': row['y'],
                'label': pixel_df['label'].iloc[0],  # Assuming label is constant
                'prediction': prediction
            }])
        # Use concat to add the new row to predictions_df
        predictions_df = pd.concat([predictions_df, new_row_df], ignore_index=True)
    # Save predictions
    predictions_df.to_csv(os.path.join(output_path, "predictions.csv"), index=False)

    # Convert to a GeoDataFrame
    gdf = gpd.GeoDataFrame(
        predictions_df,
        geometry=[Point(xy) for xy in zip(predictions_df.x, predictions_df.y)],
        crs="EPSG:3035"  # Assuming original coordinates are in WGS84
    )

    # Save to a shapefile
    gdf.to_file(os.path.join(output_path, "predictions.shp"))
    return predictions_df

def predict_csv3(model, refdir, args_predict):
    print(f"Preprocessing the Data for Prediction ...")
    print(time.gmtime())
    # Read TIFF files
    order = args_predict["order"]
    normalizing_factor = args_predict["norm_factor_features"]
    chunksize = args_predict["chunksize"]
    year = int(args_predict['time_range'][0])
    month = int(args_predict['time_range'][1].split('-')[0])
    day = int(args_predict['time_range'][1].split('-')[1])
    
    # Move model to the appropriate device
    device = next(model.parameters()).device

    # get filename list
    file_pattern = os.path.join('/ugh_mount/npy/', '*_doy.npy')
    files = glob.glob(file_pattern)

    ids = [os.path.basename(f).split('_')[0] for f in files]
    # ids = [os.path.basename(f).split('_')[0] for f in files][0:10]
    predictions = []
    for id in ids:
        batch = np.load('/ugh_mount/npy/' + id + '_bands.npy')
        doy = np.load('/ugh_mount/npy/' + id + '_doy.npy')
        doy_single = doy[0].tolist()
        doy = np.array(doy_single)
        non_zero_mask = np.any(batch != 0, axis=(1, 2))
        doy = np.tile(doy, (batch.shape[0], 1))

        if not np.any(non_zero_mask):
            batch_predictions = torch.full((batch.shape[0], 1), -9999, dtype=torch.float32, device=device)
        else:
            batch_non_zero = batch[non_zero_mask]
            doy_non_zero = doy[non_zero_mask]
            batch_tensor = torch.tensor(batch_non_zero, dtype=torch.float32, device=device)
            doy_tensor = torch.tensor(doy_non_zero, dtype=torch.long, device=device)

            predictions_non_zero = model(batch_tensor, doy_tensor)[0]

            # Handle normalization response factor
            norm_factor_response = args_predict.get("norm_factor_response")
            if norm_factor_response == "log":
                predictions_non_zero = torch.pow(10, predictions_non_zero) - 1
            elif norm_factor_response is not None and norm_factor_response != 0:
                predictions_non_zero = predictions_non_zero / norm_factor_response

            if args_predict["response"] == "classification" and not args_predict["probability"]:
                predictions_non_zero = torch.argmax(predictions_non_zero, dim=1).unsqueeze(1)  # Ensure 2D
                predictions_non_zero = predictions_non_zero.to(torch.float32)

            batch_predictions = torch.full((batch.shape[0], *predictions_non_zero.shape[1:]), -9999, dtype=torch.float32, device=device)
            batch_predictions[non_zero_mask] = predictions_non_zero

        predictions.append(batch_predictions[0].cpu())  # Move predictions back to CPU if needed

    return ids, predictions

def predict_init(args_predict, proc_folder, temp_folder, **kwargs):

    if not args_predict['reference_folder']:
        if isinstance(args_predict['aois'], list):
            for basen in args_predict['aois']:
                basename = os.path.basename(basen)
                args_predict['folder_path'] = f"{temp_folder}/{args_predict['project_name']}/FORCE/{basename}/tiles_tss/X*"

                predict_raster(args_predict)
                files = glob.glob(f"{temp_folder}/{args_predict['project_name']}/FORCE/{basename}/tiles_tss/X*/predicted.tif")
                output_filename = f"{proc_folder}/{args_predict['project_name']}/{os.path.basename(basen.replace('.shp','.tif'))}"

                mosaic_rasters(files, output_filename)
        else:
            predict_raster(args_predict)

    else:
        predict_raster(args_predict, args_predict['reference_folder'])
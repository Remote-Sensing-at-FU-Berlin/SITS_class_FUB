import torch
import numpy as np
from torch.utils.data import Dataset, DataLoader, random_split
import os
import glob
import tifffile
import torch.nn.functional as F
import torch.nn as nn
import torchvision.transforms as T


# these are some settings for augmentation
augmentations = T.Compose([
    T.RandomHorizontalFlip(),
    T.RandomVerticalFlip(),
    T.RandomRotation(30),  # degrees
    T.RandomAffine(degrees=0, translate=(0.1, 0.1), scale=(0.9, 1.1)),
])

# apparently my chips differ in sizeso i need this function for padding
def pad_to_size(img_tensor, target_size=(51, 51)):
    _, h, w = img_tensor.shape
    pad_h = target_size[0] - h
    pad_w = target_size[1] - w
    padding = [pad_w // 2, pad_w - pad_w // 2, pad_h // 2, pad_h - pad_h // 2]  # left, right, top, bottom
    return F.pad(img_tensor, padding, mode='constant', value=0)

# class for enabling dataset augmentation after random split
class TransformingSubset(Dataset):
    def __init__(self, subset, transform=None):
        self.subset = subset
        self.transform = transform

    def __getitem__(self, index):
        x, y = self.subset[index]
        if self.transform:
            x = self.transform(x)
        return x, y

    def __len__(self):
        return len(self.subset)
    
# class that defines my dataset
class TIFDataset(Dataset):
    def __init__(self, image_dir, label_file, transform=None):
        self.image_dir = image_dir
        self.transform = transform
        
        # Cargar etiquetas
        self.labels = {}
        with open(label_file, 'r') as f:
            next(f) #skip header
            for line in f:
                # Split on whitespace and clean empty strings
                parts = line.strip().split()
                
                if len(parts) >= 2:
                    filename = os.path.basename(parts[0]).strip('"')  # Get just the filename
                    self.labels[filename] = int(parts[1])
                else:
                    print(f"Skipping malformed line: {line.strip()}")
        
        all_images = glob.glob(os.path.join(image_dir, '*.tif'))
        
        # 3. Match basenames exactly (case-sensitive)
        self.image_files = [
            f for f in all_images 
            if os.path.basename(f) in self.labels
        ]

        if self.transform:
            img_tensor = self.transform(img_tensor)


        
        # Debug output
        print(f"Found {len(self.image_files)}/{len(all_images)} images with labels")
        if len(self.image_files) == 0:
            print("Warning: No images matched! Example labels:", list(self.labels.keys())[:3])
            print("Example image files:", [os.path.basename(f) for f in all_images[:3]])

    def __len__(self):
        return len(self.image_files)
    
    def __getitem__(self, idx):

            img_path = self.image_files[idx]
            img_array = tifffile.imread(img_path).astype(np.float32)
            img_array = np.nan_to_num(img_array, nan=0.0)
            if np.any(np.isnan(img_array)):
                print(f"NaNs found in image: {img_path}")

            if img_array.ndim == 2:
                img_array = np.stack([img_array] * 4, axis=-1)
            elif img_array.shape[-1] == 3:
                h, w = img_array.shape[:2]
                img_array = np.dstack([img_array, np.zeros((h, w), dtype=np.float32)])

            # Normalize to [0,1]
            img_tensor = torch.from_numpy(img_array).permute(2, 0, 1) / 255.0
            
            # padding
            img_tensor = pad_to_size(img_tensor, target_size=(51, 51))

            label = torch.tensor(self.labels[os.path.basename(img_path)], dtype=torch.float32)

            if self.transform:
                img_tensor = self.transform(img_tensor)

            return img_tensor, torch.tensor(label, dtype=torch.float)

dataset = TIFDataset(
    image_dir="/mnt/j/54TB/Jonathan/MSN/CNN/Orthos_CNN_Referenzdaten/chips",
    label_file="/mnt/j/54TB/Jonathan/MSN/CNN/labels.txt"
)


# 80% train, 10% val, 10% test
total_size = len(dataset)
train_size = int(0.8 * total_size)
val_size = int(0.1 * total_size)
test_size = total_size - train_size - val_size

train_set, val_set, test_set = random_split(dataset, [train_size, val_size, test_size])

train_set = TransformingSubset(train_set, transform=augmentations)
val_set = TransformingSubset(val_set)  # no augmentations
test_set = TransformingSubset(test_set)  # no augmentations

train_loader = DataLoader(train_set, batch_size=32, shuffle=True)
val_loader = DataLoader(val_set, batch_size=32, shuffle=False)
test_loader = DataLoader(test_set, batch_size=32, shuffle=False)

class SpeciesClassifier(nn.Module):
    def __init__(self, input_channels=4):
        super(SpeciesClassifier, self).__init__()
        self.conv1 = nn.Conv2d(input_channels, 32, kernel_size=3, stride=1, padding=1)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1)

        self.adaptive_pool = nn.AdaptiveAvgPool2d((6, 6))  # Output shape (64, 6, 6)

        self.fc1 = nn.Linear(64 * 6 * 6, 128)
        self.fc2 = nn.Linear(128, 1)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = self.adaptive_pool(x)
        x = x.view(x.size(0), -1)  #flatten
        x = F.relu(self.fc1(x))
        x = self.fc2(x) 
        return x

# define models here
def get_model(model_type='cnn'):
    if model_type == 'cnn':
        return SpeciesClassifier(input_channels=4)
    elif model_type == 'vit':
        from torchvision.models.vision_transformer import vit_b_16
        model = vit_b_16(pretrained=False)
        model.conv_proj = nn.Conv2d(4, model.conv_proj.out_channels, kernel_size=16, stride=16)
        model.heads = nn.Linear(model.heads.in_features, 1)
        return model
    else:
        raise ValueError("Unknown model type")
    
# Initialize model, change to 'vit' for vision transformer
model = get_model('cnn')
print(model)
 
import torch.optim as optim
 
# Loss and optimizer
criterion = nn.BCEWithLogitsLoss()
optimizer = optim.Adam(model.parameters(), lr=1e-5)
 
# Training loop
num_epochs = 2
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
 
for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0
    for i, (inputs, labels) in enumerate(train_loader):
        inputs, labels = inputs.to(device), labels.to(device)
 
        # Zero gradients
        optimizer.zero_grad()
 
        # Forward pass
        outputs = model(inputs)
        loss = criterion(outputs.squeeze(), labels)
 
        # Backward pass and optimize
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
 
        running_loss += loss.item()
 
        if (i + 1) % 10 == 0:
            print(f"Epoch [{epoch+1}/{num_epochs}], Step [{i+1}/{len(train_loader)}], Loss: {loss.item():.4f}")
 
    print(f"Epoch [{epoch+1}/{num_epochs}], Avg Loss: {running_loss/len(train_loader):.4f}")

    model.eval()
    val_loss = 0.0
    with torch.no_grad():
        for inputs, labels in val_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            loss = criterion(outputs.squeeze(), labels)
            val_loss += loss.item()

    avg_val_loss = val_loss / len(val_loader)
    print(f"Epoch [{epoch+1}/{num_epochs}], Validation Loss: {avg_val_loss:.4f}")
 


model.eval()
test_loss = 0.0
with torch.no_grad():
    for inputs, labels in test_loader:
        inputs, labels = inputs.to(device), labels.to(device)
        outputs = model(inputs)
        loss = criterion(outputs.squeeze(), labels)
        test_loss += loss.item()

avg_test_loss = test_loss / len(test_loader)
print(f"Test Loss: {avg_test_loss:.4f}")

model.eval()
with torch.no_grad():
    for inputs, _ in test_loader:
        inputs = inputs.to(device)
        outputs = torch.sigmoid(model(inputs)).squeeze()  # BCEWithLogitsLoss requires logits; sigmoid converts to prob
        print(outputs[:5])  # just preview first few outputs
        break  # remove to process the whole test set
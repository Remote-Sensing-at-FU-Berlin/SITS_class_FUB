library(sf)
library(dplyr)

pckg = sf::st_read('/mnt/j/54TB/Jonathan/MSN/CNN/traitdata_dirty.gpkg')
uni = unique(pckg)

duplicates <- pckg %>%
  group_by(across(everything())) %>%  # Group by all columns
  filter(n() > 1) %>%                # Keep only groups with more than one row
  arrange(across(everything()))    

filenames = dplyr::select(uni, UID_2)
labels = dplyr::select(uni, c(UID_2, FK_STP, ts))

path = '/mnt/j/54TB/Jonathan/MSN/CNN/Orthos_CNN_Referenzdaten/chips/'

labels$filepath = paste0(path, labels$UID_2, '.tif')
labels = select(labels, filepath, ts)
labels = sf::st_drop_geometry(labels)

sf::st_write(uni, '/mnt/j/54TB/Jonathan/MSN/CNN/traindata_clean.gpkg')
write.table(filenames, '/mnt/j/54TB/Jonathan/MSN/CNN/filenames.txt' )
write.table(labels, '/mnt/j/54TB/Jonathan/MSN/CNN/labels.txt', row.names = FALSE)

#!/bin/bash
set -x

# --- CONFIGURATION ---
REMOTE_USER="eouser"
REMOTE_HOST="74.63.2.205"
SSH_KEY="/home/j/.ssh/mykey2.ppk"
REMOTE_BASE="/force/FORCE/C1/L2/ard"
LOCAL_DEST="/mnt/j/54TB/FORCE_BW"
TILE_FILE="/mnt/j/54TB/Jonathan/MSN/tiles_bw.txt"
RSYNC_LOG="/tmp/rsync_debug_${TILE}.log"

# --- DATE RANGE ---
DATE_START=20200801
DATE_END=20230801

# --- LOOP OVER TILES FROM FILE ---
while IFS= read -r TILE; do
  TILE=$(echo "$TILE" | xargs)  # Trim whitespace
  [[ -z "$TILE" ]] && continue  # Skip empty lines

  echo "Estimating size for tile: $TILE"

  # Create dynamic include pattern file
  INCLUDE_FILE=$(mktemp)
#   cat "$INCLUDE_FILE"
#   echo "+ ${TILE}/" >> "$INCLUDE_FILE"

  # Generate include rules based on date and sensor
  for YEAR in {2020..2023}; do
    for MONTH in $(seq -w 1 12); do
      for DAY in $(seq -w 1 31); do
        DATE="${YEAR}${MONTH}${DAY}"
        if [[ $DATE -ge $DATE_START && $DATE -le $DATE_END ]]; then
        #   echo "+ ${TILE}/${DATE}_LEVEL2_SEN2A*" >> "$INCLUDE_FILE"
        #   echo "+ ${TILE}/${DATE}_LEVEL2_SEN2B*" >> "$INCLUDE_FILE"
        fi
      done
    done
  done

  echo "- *" >> "$INCLUDE_FILE"

  RSYNC_OUTPUT=$(rsync -av --dry-run --stats \
    --include-from="$INCLUDE_FILE" \
    -e "ssh -i $SSH_KEY" \
    "$REMOTE_USER@$REMOTE_HOST:$REMOTE_BASE/" \
    "$LOCAL_DEST/" 2>&1)


  # Extract raw size (strip dots/spaces to make a valid number)
  RAW_SIZE=$(echo "$RSYNC_OUTPUT" | grep "Total file size" | awk -F: '{gsub(/[^0-9]/,"",$2); print $2}')

  if [[ -n "$RAW_SIZE" ]]; then
    HR_SIZE=$(numfmt --to=iec --suffix=B "$RAW_SIZE")
    echo "Total size for tile $TILE: $HR_SIZE"
  else
    echo "  Could not determine size for tile $TILE (no matching files or other rsync error)"
  fi

  rm "$INCLUDE_FILE"

done < "$TILE_FILE"


# a = sf::st_read('/home/j/Downloads/FORCE_datacube_grid_BW(1).gpkg')
# b = list(a$Tile_ID)
# c = unlist(b)
# write.table(c, '/mnt/j/54TB/Jonathan/MSN/tiles_bw.txt',row.names=FALSE, col.names=FALSE)
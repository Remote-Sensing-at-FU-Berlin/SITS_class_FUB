import torch
from torch.utils.data import DataLoader, random_split
import torch.nn as nn
import torch.optim as optim
from functions import augmentations, vit_transform, evaluate_model
from classes import TIFDataset, TransformingSubset, SpeciesClassifier

from torchvision.models.vision_transformer import vit_b_16

MODEL = 'vit'  # 'vit' or 'cnn'

dataset = TIFDataset(
    image_dir="/mnt/j/54TB/Jonathan/MSN/CNN/Orthos_CNN_Referenzdaten/chips",
    label_file="/mnt/j/54TB/Jonathan/MSN/CNN/labels.txt"
)

# Split data
total = len(dataset)
train_size = int(0.8 * total)
val_size = int(0.1 * total)
test_size = total - train_size - val_size
train_set, val_set, test_set = random_split(dataset, [train_size, val_size, test_size])

if MODEL == 'cnn':
    model = SpeciesClassifier()
    train_set = TransformingSubset(train_set, transform=augmentations)
else:
    model = vit_b_16(weights=None)
    model.conv_proj = nn.Conv2d(4, model.conv_proj.out_channels, kernel_size=16, stride=16)
    model.heads = nn.Linear(model.heads[0].in_features, 1)
    train_set = TransformingSubset(train_set, transform=vit_transform)

val_set = TransformingSubset(val_set)
test_set = TransformingSubset(test_set)

train_loader = DataLoader(train_set, batch_size=32, shuffle=True)
val_loader = DataLoader(val_set, batch_size=32)
test_loader = DataLoader(test_set, batch_size=32_

import torch
from torch.utils.data import DataLoader, random_split
import torch.nn as nn
import torch.optim as optim
from functions import augmentations, vit_transform, evaluate_model
from Classes import TIFDataset, TransformingSubset, SpeciesClassifier
from torchvision.models.vision_transformer import vit_b_16

MODEL = 'vit'  # 'vit' or 'cnn'
apply_padding = MODEL == 'cnn'
EPOCHS = 20 # set number of epochs
LR = 1e-5 # set learning rate

dataset = TIFDataset(
    image_dir="/mnt/j/54TB/Jonathan/MSN/CNN/Orthos_CNN_Referenzdaten/chips",
    label_file="/mnt/j/54TB/Jonathan/MSN/CNN/labels.txt"
    pad=apply_padding # whether or not to use pad_to_size() in the dataset class depending on Model choice
)

# Split data
total = len(dataset)
train_size = int(0.8 * total)
val_size = int(0.1 * total)
test_size = total - train_size - val_size
train_set, val_set, test_set = random_split(dataset, [train_size, val_size, test_size])

if MODEL == 'cnn':
    model = SpeciesClassifier()
    train_set = TransformingSubset(train_set, transform=augmentations)
else:
    model = vit_b_16(weights=None)
    model.conv_proj = nn.Conv2d(4, model.conv_proj.out_channels, kernel_size=16, stride=16)
    model.heads = nn.Linear(model.heads[0].in_features, 1)
    train_set = TransformingSubset(train_set, transform=vit_transform)

val_set = TransformingSubset(val_set)
test_set = TransformingSubset(test_set)

train_loader = DataLoader(train_set, batch_size=32, shuffle=True)
val_loader = DataLoader(val_set, batch_size=32)
test_loader = DataLoader(test_set, batch_size=32)

# Training setup
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
criterion = nn.BCEWithLogitsLoss()
optimizer = optim.Adam(model.parameters(), lr=LR)

# Training loop
for epoch in range(EPOCHS):
    model.train()
    epoch_loss = 0.0
    for inputs, labels in train_loader:
        inputs, labels = inputs.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs.view(-1), labels)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        epoch_loss += loss.item()

    # Validation
    model.eval()
    val_loss = 0.0
    with torch.no_grad():
        for inputs, labels in val_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            loss = criterion(outputs.view(-1), labels)
            val_loss += loss.item()
    print(f"Epoch {epoch+1}, Validation Loss: {val_loss / len(val_loader):.4f}")

# Final evaluation
evaluate_model(model, test_loader, device)
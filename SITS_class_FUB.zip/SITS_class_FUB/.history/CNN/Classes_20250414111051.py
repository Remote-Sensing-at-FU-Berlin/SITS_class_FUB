import os
import glob
import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset
import tifffile
from functions import pad_or_crop_to_size

class TransformingSubset(Dataset):
    def __init__(self, subset, transform=None):
        self.subset = subset
        self.transform = transform

    def __getitem__(self, index):
        x, y = self.subset[index]
        if self.transform:
            x = self.transform(x)
        return x, y

    def __len__(self):
        return len(self.subset)

class TIFDataset(Dataset):
    def __init__(self, image_dir, label_file, transform=None, pad=True):
        self.image_dir = image_dir
        self.transform = transform
        self.pad = pad
        self.metadata = {}  # initialize labels 

        with open(label_file, 'r') as f:
            next(f)
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 3:
                    uid = parts[0]
                    filename = os.path.basename(parts[1]).strip('"')
                    label = int(parts[2])
                    self.metadata[filename] = (uid, label)

        all_images = glob.glob(os.path.join(image_dir, '*.tif'))
        self.image_files = [
            f for f in all_images if os.path.basename(f) in self.labels
        ]

        print(f"Found {len(self.image_files)}/{len(all_images)} images with labels")

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        img_path = self.image_files[idx]
        img_array = tifffile.imread(img_path).astype(np.float32)
        img_array = np.nan_to_num(img_array, nan=0.0)

        if img_array.ndim == 2:
            img_array = np.stack([img_array] * 4, axis=-1)
        elif img_array.shape[-1] == 3:
            h, w = img_array.shape[:2]
            img_array = np.dstack([img_array, np.zeros((h, w), dtype=np.float32)])

        img_tensor = torch.from_numpy(img_array).permute(2, 0, 1) / 255.0

        if self.pad:
            target = (224, 224) if self.transform and 'Resize' in str(self.transform) else (51, 51)
            img_tensor = pad_or_crop_to_size(img_tensor, target_size=target)

        if self.transform:
            img_tensor = self.transform(img_tensor)

        # label = torch.tensor(self.labels[os.path.basename(img_path)], dtype=torch.float32)
        uid, label = self.metadata[os.path.basename(img_path)]


        if self.transform:
            img_tensor = self.transform(img_tensor)

        return img_tensor, label

class SpeciesClassifier(nn.Module):
    def __init__(self, input_channels=4):
        super(SpeciesClassifier, self).__init__()
        self.conv1 = nn.Conv2d(input_channels, 32, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.adaptive_pool = nn.AdaptiveAvgPool2d((6, 6))
        self.fc1 = nn.Linear(64 * 6 * 6, 128)
        self.fc2 = nn.Linear(128, 1)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = self.adaptive_pool(x)
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        return self.fc2(x)

import torch
import torch.nn.functional as F
import torchvision.transforms as T
from torchvision.transforms import v2
from sklearn.metrics import confusion_matrix, classification_report

# Augmentations
augmentations = T.Compose([
    T.RandomHorizontalFlip(),
    T.RandomVerticalFlip(),
    T.RandomRotation(30),
    T.RandomAffine(degrees=0, translate=(0.1, 0.1), scale=(0.9, 1.1)),
])

vit_transform = T.Compose([
    T.Resize((224, 224), antialias=True),
    T.Normalize(mean=[0.5]*4, std=[0.5]*4)
])

def pad_or_crop_to_size(img_tensor, target_size=(51, 51)):
    _, h, w = img_tensor.shape
    target_h, target_w = target_size

    # If larger than target, center crop
    if h > target_h or w > target_w:
        top = max(0, (h - target_h) // 2)
        left = max(0, (w - target_w) // 2)
        img_tensor = img_tensor[:, top:top+target_h, left:left+target_w]

    # Now pad if smaller
    _, h, w = img_tensor.shape
    pad_h = target_h - h
    pad_w = target_w - w
    padding = [pad_w // 2, pad_w - pad_w // 2, pad_h // 2, pad_h - pad_h // 2]  # left, right, top, bottom

    return F.pad(img_tensor, padding, mode='constant', value=0)

def evaluate_model(model, dataloader, device):
    model.eval()
    all_preds, all_labels = [], []

    with torch.no_grad():
        for inputs, labels in dataloader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            preds = torch.sigmoid(outputs).view(-1)
            preds = (preds > 0.5).float()

            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    cm = confusion_matrix(all_labels, all_preds)
    report = classification_report(all_labels, all_preds, digits=4)
    print("Confusion Matrix:\n", cm)
    print("\nClassification Report:\n", report)

def save_predictions(model, dataloader, device, output_path="predictions.txt"):
    model.eval()
    results = []

    with torch.no_grad():
        for inputs, labels, uids in dataloader:
            inputs = inputs.to(device)
            outputs = model(inputs)
            probs = torch.sigmoid(outputs).view(-1).cpu().numpy()
            preds = (probs > 0.5).astype(int)
            labels = labels.numpy()

            for uid, true_label, pred, prob in zip(uids, labels, preds, probs):
                results.append(f"{uid}\t{true_label}\t{pred}\t{prob:.4f}")

    with open(output_path, "w") as f:
        f.write("UID\tTrueLabel\tPrediction\tConfidence\n")
        f.write("\n".join(results))
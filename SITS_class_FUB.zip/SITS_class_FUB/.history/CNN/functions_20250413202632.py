import torch
import torch.nn.functional as F
import torchvision.transforms as T
from sklearn.metrics import confusion_matrix, classification_report

# Augmentations
augmentations = T.Compose([
    T.RandomHorizontalFlip(),
    T.RandomVerticalFlip(),
    T.RandomRotation(30),
    T.RandomAffine(degrees=0, translate=(0.1, 0.1), scale=(0.9, 1.1)),
])

vit_transform = T.Compose([
    T.ToTensor(),
    T.Resize((224, 224)),
    T.Normalize(mean=[0.5]*4, std=[0.5]*4)
])

def pad_to_size(img_tensor, target_size=(51, 51)):
    _, h, w = img_tensor.shape
    pad_h = target_size[0] - h
    pad_w = target_size[1] - w
    padding = [pad_w // 2, pad_w - pad_w // 2, pad_h // 2, pad_h - pad_h // 2]
    return F.pad(img_tensor, padding, mode='constant', value=0)

def evaluate_model(model, dataloader, device):
    model.eval()
    all_preds, all_labels = [], []

    with torch.no_grad():
        for inputs, labels in dataloader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            preds = torch.sigmoid(outputs).view(-1)
            preds = (preds > 0.5).float()

            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    cm = confusion_matrix(all_labels, all_preds)
    report = classification_report(all_labels, all_preds, digits=4)
    print("Confusion Matrix:\n", cm)
    print("\nClassification Report:\n", report)

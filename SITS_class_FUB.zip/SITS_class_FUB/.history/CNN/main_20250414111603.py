import torch
from torch.utils.data import DataLoader, random_split
import torch.nn as nn
import torch.optim as optim
from functions import augmentations, vit_transform, evaluate_model, save_predictions
from Classes import TIFDataset, TransformingSubset, SpeciesClassifier
from torchvision.models.vision_transformer import vit_b_16

MODEL = 'vit'  # 'vit' or 'cnn'
PADDING = MODEL == 'cnn'
EPOCHS = 5 # set number of epochs
LR = 1e-5 # set learning rate
ESPAT = 5 # early stopping patience
SEED = 42

torch.manual_seed(SEED)

dataset = TIFDataset(
    image_dir="/mnt/j/54TB/Jonathan/MSN/CNN/Orthos_CNN_Referenzdaten/chips",
    label_file="/mnt/j/54TB/Jonathan/MSN/CNN/labels.txt",
    pad = PADDING # whether or not to use pad_to_size() in the dataset class depending on Model choice
)

test_ratio = 0.1
val_ratio = 0.1

total_size = len(dataset)
test_size = int(test_ratio * total_size)
val_size = int(val_ratio * total_size)
train_size = total_size - test_size - val_size

#  Deterministic test split first
train_val_dataset, test_set = random_split(dataset, [total_size - test_size, test_size], generator=torch.Generator().manual_seed(SEED))

#  split train/val 
train_set, val_set = random_split(train_val_dataset, [train_size, val_size], generator=torch.Generator().manual_seed(SEED))

if MODEL == 'cnn':
    model = SpeciesClassifier()
    train_set = TransformingSubset(train_set, transform=augmentations)
    val_set = TransformingSubset(val_set)
    test_set = TransformingSubset(test_set)
else:
    model = vit_b_16(weights=None)
    model.conv_proj = nn.Conv2d(4, model.conv_proj.out_channels, kernel_size=16, stride=16)
    model.heads = nn.Linear(model.heads[0].in_features, 1)
    train_set = TransformingSubset(train_set, transform=vit_transform)
    val_set = TransformingSubset(val_set, transform=vit_transform)
    test_set = TransformingSubset(test_set, transform=vit_transform)

train_loader = DataLoader(train_set, batch_size=32, shuffle=True)
val_loader = DataLoader(val_set, batch_size=32)
test_loader = DataLoader(test_set, batch_size=32)

# Training setup
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
criterion = nn.BCEWithLogitsLoss()
optimizer = optim.Adam(model.parameters(), lr=LR)

best_val_loss = float('inf')
patience = ESPAT
patience_counter = 0

# Training loop
for epoch in range(EPOCHS):
    model.train()
    epoch_loss = 0.0
    for inputs, labels in train_loader:
        inputs, labels = inputs.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs.view(-1), labels)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        epoch_loss += loss.item()

    # Validation
    model.eval()
    val_loss = 0.0
    with torch.no_grad():
        for inputs, labels in val_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            loss = criterion(outputs.view(-1), labels)
            val_loss += loss.item()

    avg_val_loss = val_loss / len(val_loader)
    print(f"Epoch {epoch+1}, Validation Loss: {avg_val_loss:.4f}")

    if avg_val_loss < best_val_loss:
        best_val_loss = avg_val_loss
        patience_counter = 0
        torch.save(model.state_dict(), "best_model.pth")
    else:
        patience_counter += 1

    if patience_counter >= patience:
        print("Early stopping triggered.")
        break

# Final evaluation
evaluate_model(model, test_loader, device)
save_predictions(model, test_loader, device, output_path = '/mnt/j/54TB/Jonathan/MSN/CNN/outputs.txt')
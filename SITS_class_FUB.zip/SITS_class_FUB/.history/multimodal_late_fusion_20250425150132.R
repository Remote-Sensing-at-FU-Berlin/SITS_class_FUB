squares = sf::st_read('/mnt/j/54TB/Jonathan/MSN/CNN/Orthos_CNN_Referenzdaten/all_squares.gpkg')
SITS_prob = raster::brick('/home/j/Downloads/tsc_perc_masked_int.tif')
DOP_prob = read.table('/mnt/j/54TB/Jonathan/MSN/CNN/outputs.txt', header=TRUE)

# should   i do this on test set only or with all points including train dataset? The thing is that there will be strong overlap between points for SITStransformer and DOP
# I could use the FE based transformer instead

# square to point
points = sf::st_centroid(squares)
points$UID = points$UID_2
# join DOP on points
points = dplyr::right_join(points, DOP_prob)
# extract SITS from square

points = dplyr::rename(points, DOPprob = Confidence)
points = dplyr::rename(points, DOPrediction = Prediction)

a = SITS_prob[[1]]
b = SITS_prob[[2]]

points$SITSspruce = terra::extract(a, points)
points$SITSfir = terra::extract(b, points)


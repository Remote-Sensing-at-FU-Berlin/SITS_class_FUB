docker run -it -v /mnt/j/54TB/Jonathan/localforce:/opt/data davidfrantz/force force-level1-csd -u /data/Jakku/edc/level1/

import geopandas as gpd

# Load your reference GeoPackage
gdf = gpd.read_file("/mnt/j/54TB/Jonathan/MSN/MSN_tiles_uno.gpkg")

# Dissolve all features into a single geometry
aoi = gdf.unary_union

# Save as GeoJSON
aoi_gdf = gpd.GeoDataFrame(geometry=[aoi], crs=gdf.crs)
aoi_gdf.to_file("/mnt/j/54TB/Jonathan/MSN/aoi.geojson", driver="GeoJSON")

docker run -it -v /mnt/j/54TB/Jonathan/localforce:/opt/data davidfrantz/force

docker run -it -v /mnt/j/54TB/Jonathan/localforce:/opt/data davidfrantz/force force-level1-csd -u -s S2A,S2B /opt/data/meta

docker run -it -v /mnt/j/54TB/Jonathan/localforce:/opt/data davidfrantz/force force-level1-csd -d 20180101,20211231 -s S2A,S2B -u -n /opt/data/meta /opt/data/level1 /opt/data/queue.txt /opt/data/aoi.json.geojson
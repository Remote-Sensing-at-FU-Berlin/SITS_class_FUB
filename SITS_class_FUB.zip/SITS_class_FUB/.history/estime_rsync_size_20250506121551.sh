#!/bin/bash

# --- CONFIGURATION ---
REMOTE_USER="eouser"
REMOTE_HOST="74.63.1.81"
SSH_KEY="/home/j/.ssh/mykey2.ppk"
REMOTE_BASE="/force/FORCE/C1/L2/ard"
LOCAL_DEST="/mnt/j/54TB/FORCE_BW"
TILE_FILE="/mnt/j/54TB/Jonathan/MSN/tiles.txt"

# --- DATE RANGE ---
DATE_START=20200801
DATE_END=20230801

# --- LOOP OVER TILES FROM FILE ---
while IFS= read -r TILE; do
  TILE=$(echo "$TILE" | xargs)  # Trim whitespace
  [[ -z "$TILE" ]] && continue  # Skip empty lines

  echo "Estimating size for tile: $TILE"

  # Create dynamic include pattern file
  INCLUDE_FILE=$(mktemp)
  echo "+ ${TILE}/" >> "$INCLUDE_FILE"

  # Generate include rules based on date and sensor
  for YEAR in {2020..2023}; do
    for MONTH in {01..12}; do
      for DAY in {01..31}; do
        DATE="${YEAR}$(printf '%02d' $MONTH)$(printf '%02d' $DAY)"
        if [[ $DATE -ge $DATE_START && $DATE -le $DATE_END ]]; then
          echo "+ ${TILE}/${DATE}_LEVEL2_SEN2A*" >> "$INCLUDE_FILE"
          echo "+ ${TILE}/${DATE}_LEVEL2_SEN2B*" >> "$INCLUDE_FILE"
        fi
      done
    done
  done

  echo "- *" >> "$INCLUDE_FILE"

  # Run rsync dry-run
  rsync -av --dry-run --stats \
    --include-from="$INCLUDE_FILE" \
    -e "ssh -i $SSH_KEY" \
    "$REMOTE_USER@$REMOTE_HOST:$REMOTE_BASE/" \
    "$LOCAL_DEST/" | grep "Total file size"

  rm "$INCLUDE_FILE"
done < "$TILE_FILE"

# load BI shapes
# load raster
# extract
# confusion matrix

######
# install and/or load packages
######

list.of.packages <- c(
  "sf",
  "exactextractr",
  "terra",
  "ggplot2",
  "tibble",
  "tidyr"
)

new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]

if(length(new.packages) > 0){
  install.packages(new.packages, dep=TRUE)
}

#loading packages
for(package.i in list.of.packages){
  suppressPackageStartupMessages(
    library(
      package.i, 
      character.only = TRUE
    )
  )
}

WEIGHTED = TRUE
NO_GAPS = FALSE


# load BI shapes
# bi = sf::read_sf("/home/j/Nextcloud/Shapes/train_data/pxl_BI_3k_train_2023.shp") # balanced

if(NO_GAPS == TRUE){
bi = sf::read_sf("/home/j/Nextcloud/Shapes/test_data/Testdata_for_FE_nogaps_filtered.gpkg")  # all, but no gaps
}
bi = sf::read_sf('/mnt/j/54TB/Jonathan/Shapes/test_data/Testdata_for_BI_nogap.gpkg')

if(NO_GAPS == FALSE){
bi =  sf::read_sf("/home/j/Nextcloud/Shapes/test_data/Testdata_for_FE_gaps_filtered.gpkg")   # all, but with gaps
}
bi = st_centroid(bi)
bi = dplyr::select(bi, c(ID, encoded))
unique(bi$encoded)

## treat other_con as other_dec
bi = dplyr::mutate(bi, encoded = ifelse(encoded == 9, 8, encoded))

# balanced sampling, silver fir is smallest with 444 samples
a = bi
c0spruce = dplyr::filter(a, a$encoded == 0)
c1fir = dplyr::filter(a, a$encoded == 1)
c2dgl = dplyr::filter(a, a$encoded == 2)
c3pine = dplyr::filter(a, a$encoded == 3)
c5oak = dplyr::filter(a, a$encoded == 4)
c6redoak = dplyr::filter(a, a$encoded == 5)
c7beech = dplyr::filter(a, a$encoded == 6)
c10sycamore = dplyr::filter(a, a$encoded == 7)
c11other = dplyr::filter(a, a$encoded == 8)

nrow(c0spruce)
nrow(c1fir)
nrow(c2dgl)
nrow(c3pine)
nrow(c5oak)
nrow(c6redoak)
nrow(c7beech)
nrow(c10sycamore)
nrow(c11other)

# minority_class = 428
# Weighted sampling according to BWI


if(WEIGHTED == TRUE & NO_GAPS == TRUE) {
set.seed(420)
c0spruce_sample = c0spruce[sample(nrow(c0spruce), 3019),]
c1fir_sample = c1fir[sample(nrow(c1fir), 710),]
c2dgl_sample = c2dgl[sample(nrow(c2dgl), 302),]
c3pine_sample = c3pine[sample(nrow(c3pine), 497),]
c5oak_sample = c5oak[sample(nrow(c5oak), 631),]
c6redoak_sample = c6redoak[sample(nrow(c6redoak), 44),]
c7beech_sample = c7beech[sample(nrow(c7beech), 1936),]
c10sycamoree_sample = c10sycamore[sample(nrow(c10sycamore), 329),]
c11other_sample = c11other[sample(nrow(c11other), 1412),]
# c9otherdec_sample = c9otherdec[sample(nrow(c9otherdec), minority_class),]
all_samples = dplyr::bind_rows(c0spruce_sample, c1fir_sample, c2dgl_sample, c3pine_sample, c5oak_sample, c6redoak_sample, c7beech_sample, c10sycamoree_sample, c11other_sample)
bi = all_samples
}

if(WEIGHTED == TRUE & NO_GAPS == FALSE) {
set.seed(420)
c0spruce_sample = c0spruce[sample(nrow(c0spruce), 4250),]
c1fir_sample = c1fir[sample(nrow(c1fir), 1000),]
c2dgl_sample = c2dgl[sample(nrow(c2dgl), 425),]
c3pine_sample = c3pine[sample(nrow(c3pine), 700),]
c5oak_sample = c5oak[sample(nrow(c5oak), 887),]
c6redoak_sample = c6redoak[sample(nrow(c6redoak), 63),]
c7beech_sample = c7beech[sample(nrow(c7beech), 2725),]
c10sycamoree_sample = c10sycamore[sample(nrow(c10sycamore), 463),]
c11other_sample = c11other[sample(nrow(c11other), 1988),]
# c9otherdec_sample = c9otherdec[sample(nrow(c9otherdec), minority_class),]
all_samples = dplyr::bind_rows(c0spruce_sample, c1fir_sample, c2dgl_sample, c3pine_sample, c5oak_sample, c6redoak_sample, c7beech_sample, c10sycamoree_sample, c11other_sample)
bi = all_samples
}


# load raster
if(NO_GAPS == FALSE) {
map10 = terra::rast('/home/j/Nextcloud/Raster/maps/final_results/final_results/split_fix_10m_gap_masked.tif')
map30 = terra::rast('/home/j/Nextcloud/Raster/maps/final_results/final_results/split_fix_30m_gap_masked.tif')
}

if(NO_GAPS == TRUE) {
map10 = terra::rast('/home/j/Nextcloud/Raster/maps/final_results/final_results/split_fix_10m_nogap_masked.tif')
map30 = terra::rast('/home/j/Nextcloud/Raster/maps/final_results/final_results/split_fix_30m_nogap_masked.tif')
# map30 = terra::rast('/home/j/Nextcloud/Raster/maps/30m_10class_20to23_map_masked_gaps.tif')
# map30 = terra::rast('/home/j/Nextcloud/Raster/maps/final_results/fixfix_30m_FE_gaps_masked.tif')
}
mapt = terra::rast('/home/j/Nextcloud/Raster/Thuenen_TSC.tif')
mapt = terra::rast('/home/j/Downloads/TreeSpeciesMap.tif')
st_crs(mapt)
terra::crs(mapt) <- "EPSG:3035" # assuming that the TUM raster is using 3035
mapt_reproj <- terra::project(mapt, sf::st_crs(bi)$wkt)


bi = sf::st_transform(bi, st_crs(map10))
bi$map10 = terra::extract(map10, bi, method = 'simple', ID = FALSE, cells = FALSE)
bi = sf::st_transform(bi, st_crs(map30))
bi$map30 = terra::extract(map30, bi, method = 'simple', ID = FALSE, cells = FALSE)
bi = sf::st_transform(bi, st_crs(mapt))
bi$mapt = terra::extract(mapt, bi, method = 'simple', ID = FALSE, cells = FALSE)

# confusion matrix
data1 = dplyr::select(bi, c("encoded","map10"))
data2 = dplyr::select(bi, c("encoded","map30"))
data3 = dplyr::select(bi, c("encoded","mapt"))

data1$map10 <- data1$map10[[1]]
data2$map30 <- data2$map30[[1]]

data1 = dplyr::mutate(data1, map10 = ifelse(map10 == 9, 8, map10)) # combine others
data2 = dplyr::mutate(data2, map30 = ifelse(map30 == 9, 8, map30)) # combine others if necessary

# adjust thuenen raster values:
# 2 birch, 3 beech, 4 douglas fir, 5 oak, 6 alder,
# 8 spruce, 9 pine, 10 larch, 14 fir, 16 odh (other deciduous high life expectancy),
# 17 odl (other deciduous low life expectancy)
# TUM
# 0 Beech, 1 Dgl, 2 fir 5 Oak, 6 Pine, 7 Spruce
data3$mapt = data3$mapt$layer
nrow(data3)
unique(data3$mapt)
data3 = as.data.frame(data3)
class(data3)
data3 = na.omit(data3) # lose 50 samples that are NA in Thuenen

# Thuenen:
# data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 2, 6, mapt)) # birch to others
# data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 6, 6, mapt)) # alder to others
# data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 10, 6, mapt)) # larch to others
# data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 16, 6, mapt)) # other to other
# data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 17, 6, mapt)) # other to other
# data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 4, 2, mapt)) # dgl to dgl
# data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 5, 4, mapt)) # oak to oak
# data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 3, 5, mapt)) # beech to beech
# data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 9, 3, mapt)) # pine to pine
# data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 8, 0, mapt)) # spruce to spruce
# data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 14, 1, mapt)) # fir to fir

# TUM: 5 is empty (RedOak) 7 empty (Sycamore) 
data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 4, 8, mapt)) # other to other
data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 3, 8, mapt)) # larch to other
data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 5, 4, mapt)) # oak to oak
data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 2, 255, mapt)) # fir to fir
data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 1, 2, mapt)) # dgl to dgl
data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 255, 1, mapt)) # fir to fir
data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 0, 5, mapt)) # beech to beech
data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 6, 3, mapt)) # pine to pine
data3 = dplyr::mutate(data3, mapt = ifelse(mapt == 7, 0, mapt)) # spruce to spruce


# data3 = dplyr::mutate(data3, encoded = ifelse(encoded == 5, 8, encoded)) # redoak to other, interim
# data3 = dplyr::mutate(data3, encoded = ifelse(encoded == 6, 5, encoded)) # beech to beech
# data3 = dplyr::mutate(data3, encoded = ifelse(encoded == 7, 6, encoded)) # sycamore to other
# data3 = dplyr::mutate(data3, encoded = ifelse(encoded == 8, 6, encoded)) # other to other

#### Alternative:
# put redoak into oak
data3 = dplyr::mutate(data3, encoded = ifelse(encoded == 5, 4, encoded)) # redoak to oak
data3 = dplyr::mutate(data3, encoded = ifelse(encoded == 6, 5, encoded)) # beech to beech
data3 = dplyr::mutate(data3, encoded = ifelse(encoded == 7, 6, encoded)) # sycamore to other
data3 = dplyr::mutate(data3, encoded = ifelse(encoded == 8, 6, encoded)) # other to other

set.seed(420)
class_6_rows <- which(data3$encoded == 4)
sampled_class_6 <- sample(class_6_rows, 444)
sampled_data3_class_6 <- data3[sampled_class_6, ]
rest_data3 <- data3[-class_6_rows, ]
data3 <- rbind(rest_data3, sampled_data3_class_6)
#####

# make other class smaller by resampling
set.seed(420)
class_6_rows <- which(data3$encoded == 6)
sampled_class_6 <- sample(class_6_rows, 444)
sampled_data3_class_6 <- data3[sampled_class_6, ]
rest_data3 <- data3[-class_6_rows, ]
data3 <- rbind(rest_data3, sampled_data3_class_6)



head(data1)
head(data2$map30)
# conf matrix
conf_matrix <- table(data1$encoded, data1$map10)
conf_matrix2 <- table(data2$encoded, data2$map30)
conf_matrix3 <- table(data3$encoded, data3$mapt)

# a = read.csv('/home/j/Downloads/final30mnogap_predictions.csv')
# b = sf::st_read('/home/j/Nextcloud/Shapes/test_data/Testdata_for_FE_nogaps.gpkg')
# byid = dplyr::join_by(id == UID)
# c = dplyr::full_join(a,b, by = byid)
# conf_matrix = table(c$encoded, c$prediction)
# conf_matrix


forbi_gaps = sf::read_sf("/home/j/Nextcloud/Shapes/test_data/Testdata_for_BI_gap.gpkg")
forbi_nogaps = sf::read_sf("/home/j/Nextcloud/Shapes/test_data/Testdata_for_BI_nogap.gpkg")

NO_GAPS = FALSE

if(NO_GAPS == TRUE) {
map = terra::rast('/home/j/Nextcloud/Raster/maps/final_results/final_results/split_fix_BI_nogap_masked.tif')
bi = forbi_nogaps
}

if(NO_GAPS == FALSE) {
map = terra::rast('/home/j/Nextcloud/Raster/maps/final_results/final_results/split_fix_BI_gap_masked.tif')
bi = forbi_gaps
}

bi = dplyr::select(bi, c(ID, encoded))
unique(bi$encoded)

## treat other_con as other_dec
bi = dplyr::mutate(bi, encoded = ifelse(encoded == 9, 8, encoded))

# balanced sampling, silver fir is smallest with 444 samples
a = bi
c0spruce = dplyr::filter(a, a$encoded == 0)
c1fir = dplyr::filter(a, a$encoded == 1)
c2dgl = dplyr::filter(a, a$encoded == 2)
c3pine = dplyr::filter(a, a$encoded == 3)
c5oak = dplyr::filter(a, a$encoded == 4)
c6redoak = dplyr::filter(a, a$encoded == 5)
c7beech = dplyr::filter(a, a$encoded == 6)
c10sycamore = dplyr::filter(a, a$encoded == 7)
c11other = dplyr::filter(a, a$encoded == 8)

nrow(c0spruce)
nrow(c1fir)
nrow(c2dgl)
nrow(c3pine)
nrow(c5oak)
nrow(c6redoak)
nrow(c7beech)
nrow(c10sycamore)
nrow(c11other)


bi = sf::st_transform(bi, st_crs(map))
bi$map = terra::extract(map, bi, method = 'simple', ID = FALSE, cells = FALSE)

# confusion matrix
data1 = dplyr::select(bi, c("encoded","map"))
data1$map <- data1$map[[1]]
conf_matrix <- table(data1$encoded, data1$map)
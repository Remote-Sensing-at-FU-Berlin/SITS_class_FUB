import torch
import numpy as np
from torch.utils.data import Dataset, DataLoader
import os
import glob
import csv
 
class TIFDataset(Dataset):
    def __init__(self, image_dir, label_file, transform=None):
        self.image_dir = image_dir
        self.transform = transform
        
        # Cargar etiquetas
        self.labels = {}
        with open(label_file, 'r') as f:
            next(f) #skip header
            reader = csv.reader(f, delimiter ='\t')
            for row in reader:
                if len(row) >= 2:  # Ensure we have both filename and species
                    filename = row[0].strip('"')  # Remove quotes if present
                    species = row[1].strip('"')
                    self.labels[filename] = int(species)
                else:
                    print(f"Skipping malformed row: {row}")
        
        # Obtener lista de archivos (solo los que tienen etiqueta)
        self.image_files = [f for f in glob.glob(os.path.join(image_dir, '*.tif')) 
                          if os.path.basename(f) in self.labels]

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        img_path = self.image_files[idx]
        image = Image.open(img_path)
        
        # Convertir a numpy array y manejar 4 canales (RGBN)
        image = np.array(image)
        if len(image.shape) == 2:  # Si es monocromático
            image = np.stack([image]*4, axis=-1)
        elif image.shape[2] == 3:   # Si tiene 3 canales
            image = np.dstack([image, np.zeros(image.shape[:2])])  # Añadir canal NIR vacío
        
        # Normalizar y convertir a tensor
        image = torch.from_numpy(image).float().permute(2, 0, 1) / 255.0
        
        # Obtener etiqueta
        filename = os.path.basename(img_path)
        label = self.labels[filename]
        
        return image, torch.tensor(label, dtype=torch.float32)

dataset = TIFDataset(
    image_dir="/mnt/j/54TB/Jonathan/MSN/CNN/Orthos_CNN_Referenzdaten/chips",
    label_file="/mnt/j/54TB/Jonathan/MSN/CNN/labels.txt"
)

# Example usage
images = np.load("pure_images.npy")  # Load your pure chips (N, H, W, 4)
labels = np.load("pure_labels.npy")  # Load your labels (N,)
dataset = Dataset(images, labels)
dataloader = DataLoader(dataset, batch_size=32, shuffle=True)

import torch.nn as nn
import torch.nn.functional as F 

class SpeciesClassifier(nn.Module):
    def __init__(self, input_channels=4):
        super(SpeciesClassifier, self).__init__()
        self.conv1 = nn.Conv2d(input_channels, 32, kernel_size=3, stride=1, padding=1)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1)
        self.fc1 = nn.Linear(64 * 25 * 25, 128)  # Assuming 100x100 input
        self.fc2 = nn.Linear(128, 1)
        
    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(-1, 64 * 25 * 25)  # Flatten
        x = F.relu(self.fc1(x))
        x = torch.sigmoid(self.fc2(x))  # Output probability of species A
        return x

# Initialize model
model = SpeciesClassifier(input_channels=4)
print(model)
 
import torch.optim as optim
 
# Loss and optimizer
criterion = nn.BCELoss()  #
optimizer = optim.Adam(model.parameters(), lr=1e-4)
 
# Training loop
num_epochs = 20
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
 
for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0
    for i, (inputs, labels) in enumerate(dataloader):
        inputs, labels = inputs.to(device), labels.to(device)
 
        # Zero gradients
        optimizer.zero_grad()
 
        # Forward pass
        outputs = model(inputs)
        loss = criterion(outputs.squeeze(), labels)
 
        # Backward pass and optimize
        loss.backward()
        optimizer.step()
 
        running_loss += loss.item()
 
        if (i + 1) % 10 == 0:
            print(f"Epoch [{epoch+1}/{num_epochs}], Step [{i+1}/{len(dataloader)}], Loss: {loss.item():.4f}")
 
    print(f"Epoch [{epoch+1}/{num_epochs}], Avg Loss: {running_loss/len(dataloader):.4f}")
 
def predict_species_proportions(model, chip):
    model.eval()
    with torch.no_grad():
        chip = torch.tensor(chip).permute(2, 0, 1).unsqueeze(0).to(device)  # Add batch dim
        prob_a = model(chip).item()
        prob_b = 1 - prob_a
    return {
        'species_a_percent': prob_a * 100,
        'species_b_percent': prob_b * 100
    }

# Example usage
mixed_chip = np.random.rand(100, 100, 4)  # Replace with your mixed chip
result = predict_species_proportions(model, mixed_chip)
print(f"Species A: {result['species_a_percent']:.1f}%")
print(f"Species B: {result['species_b_percent']:.1f}%")


# def validate_model(model, val_dataloader):
#     model.eval()
#     total_mae = 0.0
#     with torch.no_grad():
#         for inputs, labels in val_dataloader:
#             inputs, labels = inputs.to(device), labels.to(device)
#             outputs = model(inputs)
#             mae = torch.abs(outputs.squeeze() - labels).mean()
#             total_mae += mae.item()
#     return total_mae / len(val_dataloader)

# # Example usage
# val_mae = validate_model(model, val_dataloader)
# print(f"Validation MAE: {val_mae:.4f}")
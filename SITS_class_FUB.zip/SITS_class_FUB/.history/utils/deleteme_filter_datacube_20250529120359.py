from datetime import datetime

# Set your date range
start_date = datetime.strptime("20200801", "%Y%m%d")
end_date = datetime.strptime("20230801", "%Y%m%d")

filtered = []
with open("/home/j/eolab_filtered_file_list.txt") as f:
    for line in f:
        line = line.strip()
        # Find DATE component in filename
        parts = line.split("/")[-1].split("_")
        if parts and parts[0].isdigit():
            file_date = datetime.strptime(parts[0], "%Y%m%d")
            if start_date <= file_date <= end_date:
                filtered.append(line)

# Save to file
with open("/home/j/filtered_files.txt", "w") as f:
    for path in filtered:
        f.write(path + "\n")

#!/bin/bash

TILE_LIST="/mnt/j/54TB/Jonathan/MSN/tiles_bw.txt"
REMOTE_BASE="/force/FORCE/C1/L2/ard"
LOCAL_BASE="/mnt"
SSH_KEY="~/.ssh/mykey2_openssh"
REMOTE_USER="eouser@74.63.1.81"

while read -r TILE; do
    echo "Processing $TILE..."
    REMOTE_PATH="$REMOTE_BASE/$TILE/"
    LOCAL_PATH="$LOCAL_BASE/$TILE"

    mkdir -p "$LOCAL_PATH"

    rsync -avz --progress \
      -e "ssh -i $SSH_KEY" \
      --include='*/' \
      --include='*SEN2A*' \
      --include='*SEN2B*' \
      --exclude='*' \
      "$REMOTE_USER:$REMOTE_PATH" \
      "$LOCAL_PATH"

done < "$TILE_LIST"
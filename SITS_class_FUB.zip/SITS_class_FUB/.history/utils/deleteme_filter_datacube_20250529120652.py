# Load file list
with open('filtered_file_list.txt') as f:
    files = [line.strip() for line in f]

# Filter for desired dates and Sentinel-2 only
from datetime import datetime

start = datetime.strptime('20200801', '%Y%m%d')
end   = datetime.strptime('20230801', '%Y%m%d')

filtered = []
for path in files:
    parts = path.split('/')[-1].split('_')
    if len(parts) < 2:
        continue
    date_str = parts[0]
    sensor   = parts[2] if len(parts) > 2 else ""
    try:
        date = datetime.strptime(date_str, '%Y%m%d')
        if start <= date <= end and ('SEN2A' in sensor or 'SEN2B' in sensor):
            filtered.append(path)
    except ValueError:
        continue  # Skip non-date-prefixed files

# Save filtered list
with open('rsync_list.txt', 'w') as f:
    for line in filtered:
        f.write(line + '\n')

#!/usr/bin/expect -f

set timeout -1
set filelist "/home/j/rsync_list.txt"
set keyfile "/home/j/.ssh/mykey2.ppk"
set passphrase "pxk123"

set fp [open $filelist r]
while {[gets $fp line] != -1} {
    spawn pscp -i $keyfile eouser@74.63.2.205:$line /mnt/j/54TB/FORCE_BW/
    expect {
        "Enter passphrase*" {
            send "$passphrase\r"
        }
    }
    expect eof
}

# #!/usr/bin/expect -f

# set timeout -1
# set filelist "/home/j/rsync_list.txt"
# set keyfile "/home/j/.ssh/mykey2.ppk"
# set passphrase "pxk123"

# set fp [open $filelist r]
# while {[gets $fp line] != -1} {
#     spawn pscp -i $keyfile eouser@74.63.2.205:$line /mnt/j/54TB/FORCE_BW/
#     expect {
#         "Enter passphrase*" {
#             send "$passphrase\r"
#         }
#     }
#     expect eof
# }


#!/usr/bin/expect -f

set timeout -1
set filelist "/home/j/rsync_list.txt"
set passphrase "pxk123"
set keyfile "/home/j/.ssh/mykey2.ppk"
set destination "/mnt/j/54TB/FORCE_BW"

set fp [open $filelist r]
while {[gets $fp line] != -1} {
    set rel_path [regsub "^/force/FORCE/C1/L2/ard/" $line ""]
    set local_path "${destination}/$rel_path"

    # Create local directory
    exec mkdir -p [file dirname $local_path]

    # Run pscp command
    spawn pscp -i $keyfile eouser@74.63.1.81:$line $local_path
    expect {
        "Enter passphrase*" {
            send "$passphrase\r"
        }
        timeout {
            puts "Connection timed out"
        }
    }
    expect eof
}

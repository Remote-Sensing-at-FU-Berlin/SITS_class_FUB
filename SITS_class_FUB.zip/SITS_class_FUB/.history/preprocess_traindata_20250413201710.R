library(sf)
library(dplyr)
library(stringr)

pckg = sf::st_read('/mnt/j/54TB/Jonathan/MSN/CNN/traindata_clean.gpkg')
uni = unique(pckg)

duplicates <- pckg %>%
  group_by(across(everything())) %>%  # Group by all columns
  filter(n() > 1) %>%                # Keep only groups with more than one row
  arrange(across(everything()))    

filenames = dplyr::select(uni, UID_2)
labels = dplyr::select(uni, c(UID_2, FK_STP_2, ts_2, Tile_ID_2))

path = '/mnt/j/54TB/Jonathan/MSN/CNN/Orthos_CNN_Referenzdaten/chips/'

labels$filepath = paste0(path, labels$UID_2, '.tif')
labels = select(labels, filepath, ts_2)
labels = sf::st_drop_geometry(labels)
ones = dplyr::filter(labels, ts_2 == 1)
twos = dplyr::filter(labels, ts_2 == 2)
ones = sample_n(ones, 1219)

labels = dplyr::full_join(ones, twos)

write.table(filenames, '/mnt/j/54TB/Jonathan/MSN/CNN/filenames.txt')
write.table(labels, '/mnt/j/54TB/Jonathan/MSN/CNN/labels.txt', row.names = FALSE)


# Replace 2 with 0 in-place
lines <- readLines("/mnt/j/54TB/Jonathan/MSN/CNN/labels.txt")
lines <- gsub(' 2$', ' 0', lines)  # assumes 2 is at end of line
writeLines(lines, "/mnt/j/54TB/Jonathan/MSN/CNN/labels.txt")

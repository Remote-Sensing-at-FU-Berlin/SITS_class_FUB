# -*- coding: utf-8 -*-
"""
Created on Tue Aug 22 20:30:26 2023

@author: benjaminstoeckigt
"""

import os
import glob
import time
from pytorch.rf_predict import predict_rf_init, load_preprocess_settings
from config_path import path_params
from force.force_class_utils import force_class

args_predict = {
    'project_name': "rf_predict",
    'model_path': '/ugh_mount/FORCE/new_struc/process/result/_SITSModels/30m_RF/rf/rf.joblib',
    # 'aois': glob.glob(f"/ugh_mount/predict1shp/predict1shp.shp"), # aois can be path or list. Path for Force Tile folder or list // process structure and shapefiles must be correct
    'aois': glob.glob(f"/ugh_mount/predict1shp/bw_force_2023.shp"), # aois can be path or list. Path for Force Tile folder or list // process structure and shapefiles must be correct
    # 'aois': None,
    'chunksize': 2000,
    # 'reference_folder' : '/uge_mount/FORCE/new_struc/process/result/_SITSrefdata/envilink_vv_3years_2020/',
    'reference_folder' : None, #Set Path if you want to predict the Test CSV File
    'probability' : False, # just gets recognized if classification
    'seqlength' : 100
}
##########################################
### Additional Setting - Can Be Ignored###
##########################################
preprocess_params = load_preprocess_settings(os.path.dirname(args_predict["model_path"]))
preprocess_params["sample"] = False
preprocess_params["project_name"] = args_predict["project_name"]
preprocess_params["aois"] = args_predict["aois"]
preprocess_params["date_ranges"] = None
preprocess_params["years"] = None
args_predict["time_range"] = preprocess_params["time_range"]
args_predict["RF"] = True


if __name__ == '__main__':
    startzeit = time.time()

    # force_class(preprocess_params, **path_params)
    predict_rf_init(args_predict, **path_params)

    endzeit = time.time()
    print(f"{(endzeit-startzeit)/60} minutes")

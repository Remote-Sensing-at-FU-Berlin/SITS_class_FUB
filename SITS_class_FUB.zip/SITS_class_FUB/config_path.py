path_params = {
    "force_dir": "/force:/force",
    "local_dir": "/ugh_mount:/ugh_mount",
    "force_skel": "/ugh_mount/git/SITS_TreeSpeC/force/skel/force_cube_sceleton",
    "scripts_skel": "/ugh_mount/git/SITS_TreeSpeC/force/skel",
    "temp_folder": "/mnt/j/54TB/Jonathan/2024/ugh_mount/FORCE/new_struc/process/temp",
    "mask_folder": "/mnt/j/54TB/Jonathan/2024/ugh_mount/FORCE/new_struc/process/mask",
    "proc_folder": "/mnt/j/54TB/Jonathan/2024/ugh_mount/FORCE/new_struc/process/results",
    "data_folder": "/mnt/j/54TB/Jonathan/2024/ugh_mount/FORCE/new_struc/data"
    }

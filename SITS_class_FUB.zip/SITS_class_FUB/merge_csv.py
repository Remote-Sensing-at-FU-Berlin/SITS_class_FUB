import pandas as pd
import glob

file_paths = {
    'BLU': '/ugh_mount/ref_folder/sepfiles/test/csv/BLU.csv',
    'BNR': '/ugh_mount/ref_folder/sepfiles/test/csv/BNR.csv',
    'GRN': '/ugh_mount/ref_folder/sepfiles/test/csv/GRN.csv',
    'NIR': '/ugh_mount/ref_folder/sepfiles/test/csv/NIR.csv',
    'RE1': '/ugh_mount/ref_folder/sepfiles/test/csv/RE1.csv',
    'RE2': '/ugh_mount/ref_folder/sepfiles/test/csv/RE2.csv',
    'RE3': '/ugh_mount/ref_folder/sepfiles/test/csv/RE3.csv',
    'RED': '/ugh_mount/ref_folder/sepfiles/test/csv/RED.csv',
    'SW1': '/ugh_mount/ref_folder/sepfiles/test/csv/SW1.csv',
    'SW2': '/ugh_mount/ref_folder/sepfiles/test/csv/SW2.csv',
}

dfs = {}

# Read each CSV file into a DataFrame and store it in the dictionary
for band, path in file_paths.items():
    df = pd.read_csv(path, index_col=0)
    df.columns = df.columns.str.replace('_x', f'_{band}')
    dfs[band] = df

# Start with the first DataFrame to initialize the merged DataFrame
merged_df = dfs.popitem()[1]

# Merge the remaining DataFrames on the 'ID' column
for band, df in dfs.items():
    merged_df = pd.merge(merged_df, df, on='ID', how='outer')

# Optionally, sort the columns by date
merged_df = merged_df.reindex(sorted(merged_df.columns), axis=1)

# Save the merged DataFrame to a new CSV file
merged_df.to_csv('merged_bands_output.csv', index=False)